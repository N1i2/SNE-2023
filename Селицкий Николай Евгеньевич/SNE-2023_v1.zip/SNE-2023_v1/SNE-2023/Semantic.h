#pragma once

namespace Semantic 
{
	void CheckSemanticAfterPolish(LexA::Tables tables);
	void CheckSemanticBeforePolish(LexA::Tables tables);
}